##Ruby on Rails コーデング規約（参考サイト）

* [Ruby on Rails Guides](http://guides.rubyonrails.org/contributing_to_ruby_on_rails.html#follow-the-coding-conventions)
* [bbatsov / rails-style-guide](https://github.com/bbatsov/rails-style-guide)
* [コーディング規約をまとめてみた (Rails編) | bojovs.com](http://bojovs.com/2012/10/16/rails-coding-style)
