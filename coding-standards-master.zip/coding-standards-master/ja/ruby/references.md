##Ruby コーデング規約（参考サイト）

* [Ruby Styleguide](https://github.com/styleguide/ruby)
* [bbatsov / ruby-style-guide](https://github.com/bbatsov/ruby-style-guide)
* [コーディング規約をまとめてみた (Ruby編) - bojovs::blog](http://bojovs.github.com/2012/04/24/ruby-coding-style/)
