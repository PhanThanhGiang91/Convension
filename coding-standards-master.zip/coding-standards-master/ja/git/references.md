##git 利用規約（参考サイト）

* [A successful Git branching model » nvie.com](http://nvie.com/posts/a-successful-git-branching-model/)
