##Javascript コーデング規約（参考サイト）

* [Google JavaScript Style Guide](http://google-styleguide.googlecode.com/svn/trunk/javascriptguide.xml)
* [Google JavaScript Style Guide 和訳](http://cou929.nu/data/google_javascript_style_guide/)
