##Rules about writing Ruby on Rails code (Reference links)
