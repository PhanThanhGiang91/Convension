##Rules about writing Ruby on Rails code (Reference links)

* [Ruby Styleguide](https://github.com/styleguide/ruby)
* [Prelude](https://github.com/bbatsov/ruby-style-guide)
* [Summary of rules about writing Ruby code - bojovs::blog](http://bojovs.github.com/2012/04/24/ruby-coding-style/)
