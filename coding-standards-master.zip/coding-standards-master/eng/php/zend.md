Please refer to the following document:
[Zend Framework Coding Standard](http://framework.zend.com/manual/1.10/en/coding-standard.html)
