# Framgia PHP Coding Standard

With PHP, we have a lot of Frameworks, each framework has its own coding standards.

In the following links, we wrote out the coding standards for each PHP Framework. 

Sometimes, we only folow official documentation of the framework.

[Phalcon](phalcon.md)

[CakePHP](cakephp.md)

[Symphony](symphony.md)

[Zend](zend.md)