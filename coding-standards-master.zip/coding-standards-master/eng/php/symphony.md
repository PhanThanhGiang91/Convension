Please refer to the following document:
[Symphony Coding Standards](http://symfony.com/doc/current/contributing/code/standards.html)
