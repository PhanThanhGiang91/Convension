##Các quy định về viết code Ruby(Các trang tham khảo)


* [Ruby Styleguide](https://github.com/styleguide/ruby)
* [Prelude](https://github.com/bbatsov/ruby-style-guide)
* [Tóm tắt các quy định về viết code Ruby - bojovs::blog](http://bojovs.github.com/2012/04/24/ruby-coding-style/)
