##Các quy định về viết code Ruby on Rails (Các trang tham khảo)
